package sample;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import java.lang.String;
import java.io.File;
import java.net.URL;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import java.sql.Connection;
import java.sql.Statement;


public class RegisterController implements Initializable {


    @FXML
    private ImageView shieldImageView;
    @FXML
    private TextField firstnameTextField;
    @FXML
    private TextField lastnameTextField;
    @FXML
    private TextField usernameTextField;
    @FXML
    private PasswordField setPasswordField;
//    @FXML
//    private Label confirmPasswordLabel;
    @FXML
    private PasswordField confirmPasswordField;
    @FXML
    private DatePicker DateDatePicker;
    @FXML
    private ChoiceBox branchChoicebox;
    @FXML
    private TextField cgpaTextField;
    ///End of Left side of Form


    //Start of Right Side of Form
    @FXML
    private TextField emailTextField;
    @FXML
    private ChoiceBox javaChoiceBox; // Choice box Java
    @FXML
    private ChoiceBox pythonChoiceBox; // Choice box Python
    @FXML
    private ChoiceBox othersChoiceBox; // Choice box others
    @FXML
    private ChoiceBox internshipChoiceBox;
    @FXML
    private TextField projects_numTextField;
    @FXML
    private TextField mobileTextField;
    @FXML
    private TextField semesterTextField;
    @FXML
    private TextField projectTitleTextField;
    @FXML
    private Button closeButton;
    @FXML
    private Button registerButton;
    @FXML
    private Label registrationMessageLabel;
    @FXML
    private Label confirmPasswordLabel;


    ObservableList<String> branchList = FXCollections.observableArrayList("CS","ECE","IT","Others");
    ObservableList<String> InternshipList = FXCollections.observableArrayList("Yes","No");
    ObservableList<String> Languages_knownList = FXCollections.observableArrayList("Yes","No");
    public void initialize(URL url, ResourceBundle resourceBundle){
        File shieldFile = new File("@../../pictures/register_logo.png");
        Image shieldimage = new Image(shieldFile.toURI().toString());
        shieldImageView.setImage(shieldimage);

        branchChoicebox.setItems(branchList) ;
        branchChoicebox.setValue("Choose any 1");

        internshipChoiceBox.setItems(InternshipList);
        internshipChoiceBox.setValue("Yes or No");

        javaChoiceBox.setItems(Languages_knownList);
        pythonChoiceBox.setItems(Languages_knownList);
        othersChoiceBox.setItems(Languages_knownList);

    }

    public void UsercloseButtonOnAction(javafx.event.ActionEvent event) {
        Stage stage = (Stage) closeButton.getScene().getWindow();
        stage.close();
        Platform.exit();

    }

    public void userRegisterButtonOnAction(javafx.event.ActionEvent event) {
        //password confirmation validation
        if (setPasswordField.getText().equals(confirmPasswordField.getText())) {
            confirmPasswordLabel.setText("You are set!");
            registerUser();
            registrationMessageLabel.setText("Registration Successfully Completed!");
        } else {
            confirmPasswordLabel.setText("Password does not match! Try Again");

        }
    }
        public void registerUser() {
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnetion();

            String firstname = firstnameTextField.getText();
            String lastname = lastnameTextField.getText();
            String username = usernameTextField.getText();
            String password = setPasswordField.getText();
            String cgpa = cgpaTextField.getText();
            String email = emailTextField.getText();
            String no_of_projects = projects_numTextField.getText();
            String mobile_number = mobileTextField.getText();
            String semester = semesterTextField.getText();
            String project_title = projectTitleTextField.getText();

            Object selectedItem2 = internshipChoiceBox.getSelectionModel().getSelectedItem();
            String internship_response = "" + selectedItem2;
            Object selectedItem = branchChoicebox.getSelectionModel().getSelectedItem();
            String branch = "" + selectedItem;
            Object selectedItem3 = javaChoiceBox.getSelectionModel().getSelectedItem();
            String java_response = "" + selectedItem3;
            Object selectedItem4 = pythonChoiceBox.getSelectionModel().getSelectedItem();
            String python_response = "" + selectedItem4;
            Object selectedItem5 = othersChoiceBox.getSelectionModel().getSelectedItem();
            String others_response = "" + selectedItem5;
            String date = DateDatePicker.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));


            String insertField = "INSERT INTO user_account(firstname,lastname,username,password,cgpa,email,no_of_projects_done,mobile_number,semester,Title_of_project,branch,internship_response,DateOfBirth,java_response,python_response,others_response) VALUES ('";
            String insertValues = firstname + "','" + lastname + "','" + username + "','" + password + "','" + cgpa + "','" + email + "','" + no_of_projects+ "','" + mobile_number + "','" + semester + "','" + project_title + "','" + branch + "','" + internship_response + "','" + date + "','" + java_response + "','" + python_response + "','" + others_response + "')";
            String insertToRegister = insertField+insertValues;
            try{
                Statement statement = connectDB.createStatement();
                statement.executeUpdate(insertToRegister);//execution part
            }catch (Exception e){
                e.printStackTrace();
                e.getCause();
            }

        }


    }
